# Ocrxfact
This is the Java Spring Boot Backend of ocrxfact. To run this project simply run the following command in the terminal.
```sh
mvn spring-boot:run
```
