package jn.ocrx.core;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.http.client.utils.URIBuilder;
import org.springframework.beans.factory.annotation.Value;
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
import org.json.simple.*;

public class SparqlQuery {
//	@Value("${graphdb.url}")

	public static String getGraphDBURL(){
		// for docker
		return "http://ocrx-graphdb:7200";
		// for dev
		// return "http://localhost:7200";
	}
	public static String runQuery(String query) throws URISyntaxException, IOException, InterruptedException {
		HttpClient client = HttpClient.newHttpClient();
		String graphdbBackend = SparqlQuery.getGraphDBURL();
		URIBuilder ub = new URIBuilder(graphdbBackend+"/repositories/ocrx-graphdb");
		ub.addParameter("query", query);
		ub.addParameter("timeout", "10");
		System.out.print("Currently querying!!!");
		// System.out.pinrtln(ub.toString());
		HttpRequest request = HttpRequest.newBuilder(URI.create(ub.toString()))
				.header("accept", "application/sparql-results+json").build();
		String response = client.send(request, BodyHandlers.ofString()).body();
		return response;
	}

	public static boolean runQueryBoolean(String query) throws URISyntaxException, IOException, InterruptedException {
		String JSON_DATA = runQuery(query);
		JSONObject obj = (JSONObject) JSONValue.parse(JSON_DATA);
		return (boolean) obj.get("boolean");
	}

	public static String escapeVariables(String variable) {
		return variable.replace("\"", "\\\"");
	}

	public static String insertVariables(String query, String... strings) {
		ArrayList<String> escapedStrings = new ArrayList<>();
		for (String string : strings) {
			escapedStrings.add(escapeVariables(string));
		}
		return String.format(query, (Object[]) escapedStrings.toArray());
	}

	public static ArrayList<String> queryDINFromOcrxId(String ocrxId)
			throws URISyntaxException, IOException, InterruptedException {
		String queryTemplate = "PREFIX owl: <http://www.w3.org/2002/07/owl#>\n"
				+ "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
				+ "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n"
				+ "PREFIX OCRx: <http://www.ocrx.ca/OCRx/>\n"
				+ "# replace s or n to get findRelatedDin or findRelatedOCRx\n" + "select * where {\n"
				+ "    <http://www.ocrx.ca/OCRx/%s> <http://www.ocrx.ca/OCRx/BrandedID> ?din .\n" + "} limit 100 \n"
				+ "";
		String query = insertVariables(queryTemplate, ocrxId);
		String sparqlResult = runQuery(query);
		JSONObject obj = (JSONObject) JSONValue.parse(sparqlResult);
		return (ArrayList<String>) ga(gjr(obj,"results","bindings")).stream().map((el) -> gj(el,"din","value")).collect(Collectors.toCollection(ArrayList::new));

	}

	@SuppressWarnings("unchecked")
	static ArrayList<String> getBindingsFromSparqlResult(String sparqlResult) {
		JSONObject obj = (JSONObject) JSONValue.parse(sparqlResult);
		JSONArray arr = (JSONArray) ((JSONObject) (obj.get("results"))).get("bindings");
		ArrayList<String> strings = (ArrayList<String>) arr.stream().map((rawEl) -> {
			JSONObject el = (JSONObject) ((JSONObject) rawEl).get("ocrx_id");
			String completeURI = (String) el.get("value");
			String[] parts = completeURI.split("/");
			return parts[parts.length - 1];
		}).collect(Collectors.toCollection(ArrayList::new));
		return strings;
	}

	public static ArrayList<String> queryOcrxIdFromDin(String din)
			throws URISyntaxException, IOException, InterruptedException {
		String queryTemplate = "PREFIX owl: <http://www.w3.org/2002/07/owl#>\n"
				+ "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
				+ "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n"
				+ "PREFIX OCRx: <http://www.ocrx.ca/OCRx/>\n"
				+ "# replace s or n to get findRelatedDin or findRelatedOCRx\n" + "select * where {\n"
				+ "    ?ocrx_id <http://www.ocrx.ca/OCRx/BrandedID> \"%s\" .\n" + "} limit 100 \n" + "";
		String query = insertVariables(queryTemplate, din);
		String sparqlResult = runQuery(query);
		return getBindingsFromSparqlResult(sparqlResult);
	}

	static boolean queryOcrxIdIsDrug(String ocrxId) throws URISyntaxException, IOException, InterruptedException {
		String queryTemplate = "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
				+ "PREFIX owl: <http://www.w3.org/2002/07/owl#>\n"
				+ "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n"
				+ "#PREFIX OCRx: <http://www.ocrx.ca/OCRx/>\n" + "ASK  where {\n"
				+ "    BIND (<http://www.ocrx.ca/OCRx/%s> as ?s)\n" + "	?s a owl:Class.\n"
				+ "    ?s rdfs:label ?sLabel .\n" + "    ?s owl:equivalentClass ?sPart .\n"
				+ "    ?sPart owl:intersectionOf ?sFull .\n" + "    ?sFull rdf:first ?sCategory .\n"
				+ "    ?sCategory rdfs:label ?sCategoryValue .\n" + "    ?sCategory rdfs:subClassOf ?type .\n"
				+ "    ?type rdfs:label \"Canadian clinical drug\"@en\n" + "} limit 1";
		String query = insertVariables(queryTemplate, ocrxId);
		return runQueryBoolean(query);

	}

	public static boolean queryValidOcrxId(String ocrxId) {
		String queryTemplate = "PREFIX owl: <http://www.w3.org/2002/07/owl#>\n" + "ASK  where {\n"
				+ "    BIND (<http://www.ocrx.ca/OCRx/%s> as ?s)\n" + "	?s a owl:Class.\n" + "} limit 1";
		String query = insertVariables(queryTemplate, ocrxId);
		try {
			return runQueryBoolean(query);
		} catch (Exception e) {
			return false;
		}

	}

	static String queryTypeFromOcrxIdNotDrug(String ocrxId)
			throws URISyntaxException, IOException, InterruptedException {
		String queryTemplate = "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
				+ "select ?parentName where { \n" + "	<http://www.ocrx.ca/OCRx/%s> rdfs:subClassOf ?parent .\n"
				+ "    ?parent rdfs:label ?parentName\n" + "} limit 1 ";
		String query = insertVariables(queryTemplate, ocrxId);
		String JSON_DATA = runQuery(query);
		JSONObject obj = (JSONObject) JSONValue.parse(JSON_DATA);
		JSONArray arr = (JSONArray) ((JSONObject) obj.get("results")).get("bindings");
		JSONObject el1 = (JSONObject) ((JSONObject) arr.get(0)).get("parentName");
		return (String) el1.get("value");
	}

	public static String queryTypeFromOcrxId(String ocrxId) {
		try {
			if (!queryValidOcrxId(ocrxId))
				return "None";
			boolean isClinicalDrug = queryOcrxIdIsDrug(ocrxId);
			if (isClinicalDrug)
				return "Canadian clinical drug";
			return queryTypeFromOcrxIdNotDrug(ocrxId);
		} catch (Exception e) {
			return "None";
		}
	}
	static Object gjr(Object obj, String ...keys) {
		JSONObject newObj = (JSONObject) obj;
		for (int i = 0; i < keys.length - 1; i++) {
			newObj = (JSONObject) newObj.get(keys[i]);
		}
		return newObj.get(keys[keys.length-1]);
	}
	static String gj(Object obj, String ...keys) {
		JSONObject newObj = (JSONObject) obj;
		for (int i = 0; i < keys.length - 1; i++) {
			newObj = (JSONObject) newObj.get(keys[i]);
		}
		return (String) newObj.get(keys[keys.length-1]);
	}
	
	static JSONArray ga(Object obj) {
		return (JSONArray) obj;
	}
	
	public static JSONObject queryRefs(String ocrxId) throws URISyntaxException, IOException, InterruptedException {
		if (!queryValidOcrxId(ocrxId)) {
			return new JSONObject();
		}
		String queryTemplate = "PREFIX owl: <http://www.w3.org/2002/07/owl#>\n"
				+ "PREFIX XRef: <http://www.ocrx.ca/OCRx/XRef:>\n"
				+ "select * where {\n"
				+ "    BIND (<http://www.ocrx.ca/OCRx/%s> as ?s)\n"
				+ "	?s a owl:Class .\n"
				+ "    ?s <http://www.ocrx.ca/OCRx/XRef:RXNORM> ?rxcui .\n"
				+ "    ?s <http://www.ocrx.ca/OCRx/XRef:CCDD> ?ccdd .\n"
				+ "    ?s <http://www.ocrx.ca/OCRx/XRef:GINAS> ?ginas .\n"
				+ "    ?s <http://www.ocrx.ca/OCRx/XRef:ANSM-CODECIS> ?codecis\n"
				+ "} limit 1";
		String query = insertVariables(queryTemplate,ocrxId);
		String JSON_DATA = runQuery(query);
		JSONObject obj = (JSONObject) JSONValue.parse(JSON_DATA);
		JSONObject el = (JSONObject) ga(gjr(obj,"results","bindings")).get(0);
		JSONObject result = new JSONObject();
		List<String> types = Arrays.asList("rxcui","ccdd","ginas","codecis");
		for (String type : types) {
			result.put(type, gj(el,type,"value"));
		}
		result.put("ocrx_id", ocrxId);
		return result;
	}
	public static JSONObject queryRef(String ocrxId,String property) throws URISyntaxException, IOException, InterruptedException {
		String queryTemplate = "PREFIX owl: <http://www.w3.org/2002/07/owl#>\n"
				+ "PREFIX XRef: <http://www.ocrx.ca/OCRx/XRef:>\n"
				+ "select * where {\n"
				+ "    BIND (<http://www.ocrx.ca/OCRx/%s> as ?s)\n"
				+ "	?s a owl:Class .\n"
				+ "    ?s <http://www.ocrx.ca/OCRx/XRef:%s> ?%s .\n"
				+ "} limit 1";
		if (!queryValidOcrxId(ocrxId)) {
			return new JSONObject();
		}
		HashMap<String,String> displayMappings = new HashMap<String,String>();
		displayMappings.put("rxcui", "RXNORM");
		displayMappings.put("ccdd", "CCDD");
		displayMappings.put("ginas", "GINAS");
		displayMappings.put("codecis", "ANSM-CODECIS");
		if (!displayMappings.containsKey(property)) {
			return new JSONObject();
		}
		String displayProperty = displayMappings.get(property);
		String query = insertVariables(queryTemplate,ocrxId,displayProperty,property);
		String JSON_DATA = runQuery(query);
		JSONObject obj = (JSONObject) JSONValue.parse(JSON_DATA);
		JSONObject el = (JSONObject) ga(gjr(obj,"results","bindings")).get(0);
		JSONObject result = new JSONObject();
		result.put(property,gj(el,property,"value"));
		result.put("ocrx_id", ocrxId);
		return result;
	}

	public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
		// System.out.pinrtln("hello world!");
		System.out.printf("Querying ocrx id: 1234567 -> %b\n", queryValidOcrxId("1234567"));
		String testDin = "DIN02237618";
		System.out.printf("Finding ocrx id for %s -> %s\n", testDin, queryOcrxIdFromDin(testDin).toString());
		String testDrugOcrxId = "1000000038";
		System.out.printf("Finding type from ocrx id %s -> %s\n", testDrugOcrxId, queryTypeFromOcrxId(testDrugOcrxId));
		String testDrugOcrxId2 = "3000000566";
		System.out.printf("Finding type from ocrx id %s -> %s\n", testDrugOcrxId2, queryTypeFromOcrxId(testDrugOcrxId2));;
		System.out.printf("Querying refs for %s -> %s\n", "3000004942",queryRefs("3000004942").toJSONString());
		System.out.printf("Querying refs for %s -> %s\n", "3000004942",queryRef("3000004942","rxcui").toJSONString());
	}

}
