package jn.ocrx.core;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.expression.OWLEntityChecker;
import org.semanticweb.owlapi.expression.ShortFormEntityChecker;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.util.BidirectionalShortFormProviderAdapter;
import org.semanticweb.owlapi.util.ShortFormProvider;
import org.semanticweb.owlapi.util.SimpleShortFormProvider;
import org.semanticweb.owlapi.util.mansyntax.ManchesterOWLSyntaxParser;

public class DLqueryTest {

	public static void main(String[] args, OWLDataFactory factory, OWLOntology OCRx, OWLReasoner reasoner, OWLOntologyManager ontomanager) {
		// TODO Auto-generated method stub
		// attention tu dois déjà avoir initialiser le reasoner et avoir a ta disposition les factory, manager et ontology
		String query = "4000000000";
		// System.out.pinrtln(query);
		
		ShortFormProvider prefixe = new SimpleShortFormProvider();
		OWLEntityChecker entityChecker = new ShortFormEntityChecker( new BidirectionalShortFormProviderAdapter(ontomanager,OCRx.getImportsClosure(), prefixe));// System.out.pinrtln(query);
		OWLClassExpression qeryTest =DLqeriSyntax(query, factory, entityChecker, OCRx);
		
		// le résultat est donné sous forme d'IRI pour juste avoir les codes un traitement additionnel est nécessaire
		Set<OWLClass> resu2 =reasoner.getSubClasses(qeryTest,false).getFlattened();
		// traitement pour avoir les codes uniquement
		Set<String> resultat = new HashSet<String>();
		for(OWLClass cal : resu2) {
			String ccd = cal.getIRI().getShortForm();
			resultat.add(ccd);
		}

	}
	
	private static OWLClassExpression DLqeriSyntax(String QueryInManchesterSyntax, OWLDataFactory ontologyFactory,OWLEntityChecker entityChecker, OWLOntology ontology) {
		ManchesterOWLSyntaxParser parser = OWLManager.createManchesterParser();
		parser.setDefaultOntology(ontology);
		parser.setOWLEntityChecker(entityChecker);
		parser.setStringToParse(QueryInManchesterSyntax);
		OWLClassExpression classeExpression=parser.parseClassExpression();
		return classeExpression;
	}

}