package jn.ocrx.core;

import java.util.Set;


/**
 * a mettre dans le beans 
 * @author jnnikiema
 *
 */
public class RxConcept{
	
	private java.lang.String Comment;
    private Set<String> STR;
    private java.lang.String RXCUI;
    private java.lang.String TTY;
    
    public RxConcept(
            java.lang.String RXCUI,
            Set<String>STR,
            java.lang.String Comment,
            java.lang.String TTY) {
            
            this.setRXCUI(RXCUI);
            this.STR = STR;
            this.setTTY(TTY);
            this.setComment(Comment);
     }

	public java.lang.String getTTY() {
		return TTY;
	}

	public void setTTY(java.lang.String tTY) {
		TTY = tTY;
	}

	public java.lang.String getRXCUI() {
		return RXCUI;
	}

	public void setRXCUI(java.lang.String rXCUI) {
		RXCUI = rXCUI;
	}

	public Set<String> getSTR() {
		return STR;
	}

	public void setSTR(Set<String> sTR) {
		STR = sTR;
	}

	public java.lang.String getComment() {
		return Comment;
	}

	public void setComment(java.lang.String comment) {
		Comment = comment;
	}
	
	
	private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RxConcept)) return false;
        RxConcept other = (RxConcept) obj;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.Comment==null && other.getComment()==null) || 
             (this.Comment!=null &&
              this.Comment.equals(other.getComment())))  &&
            ((this.RXCUI==null && other.getRXCUI()==null) || 
             (this.RXCUI!=null &&
              this.RXCUI.equals(other.getRXCUI()))) &&
            ((this.STR==null && other.getSTR()==null) || 
             (this.STR!=null &&
              this.STR.equals(other.getSTR()))) &&
            ((this.TTY==null && other.getTTY()==null) || 
             (this.TTY!=null &&
              this.TTY.equals(other.getTTY())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getComment() != null) {
            _hashCode += getComment().hashCode();
        }
       
        if (getRXCUI() != null) {
            _hashCode += getRXCUI().hashCode();
        }
        if (getSTR() != null) {
            _hashCode += getSTR().hashCode();
        }
        if (getTTY() != null) {
            _hashCode += getTTY().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }


}
