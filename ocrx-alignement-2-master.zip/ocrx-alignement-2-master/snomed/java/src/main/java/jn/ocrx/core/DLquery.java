package jn.ocrx.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.expression.OWLEntityChecker;
import org.semanticweb.owlapi.expression.ShortFormEntityChecker;
import org.semanticweb.owlapi.model.OWLAnnotationAssertionAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.search.EntitySearcher;
import org.semanticweb.owlapi.util.BidirectionalShortFormProviderAdapter;
import org.semanticweb.owlapi.util.ShortFormProvider;
import org.semanticweb.owlapi.util.SimpleShortFormProvider;
import org.semanticweb.owlapi.util.mansyntax.ManchesterOWLSyntaxParser;

public class DLquery {
	
	private Set<RxClinicalDrug> clinicaldrugs;
	private ArrayList<Map<String,String>> queryResult;

	public DLquery(String query, OWLReasoner reasoner,OWLOntology OCRx, OWLOntologyManager ontomanager,OWLDataFactory factory) {
		ShortFormProvider prefixe = new SimpleShortFormProvider();
		OWLEntityChecker entityChecker = new ShortFormEntityChecker( new BidirectionalShortFormProviderAdapter(ontomanager,OCRx.getImportsClosure(), prefixe));// System.out.pinrtln(query);
		OWLClassExpression queryTest =DLquerySyntax(query, factory, entityChecker, OCRx);
		
		
		
		Set<OWLClass> resu2 =reasoner.getSubClasses(queryTest,false).getFlattened();
		// Set<OWLClass> resu =reasoner.getEquivalentClasses(queryTest).getEntities();
		ArrayList<Map<String,String>> results = new ArrayList<>();
		for (OWLClass el : resu2){
			var annotations = EntitySearcher.getAnnotationAssertionAxioms(el, OCRx);
			var equiv = EntitySearcher.getEquivalentClasses(el, OCRx);
			for (OWLClassExpression el2 : equiv){
				Set<OWLObjectProperty> property = el2.getObjectPropertiesInSignature();
				OWLObjectProperty individual_property = property.iterator().next();

				
				
			}
			Map<String,String> map = new HashMap<>();
			map.put("iri",el.getIRI().getShortForm());
			for (var annotation: annotations){
				var annot = annotation.getAnnotation();
				String property = annot.getProperty().getIRI().getShortForm();
				String value = annot.getValue().asLiteral().get().getLiteral();
				map.put(property,value);
			}
			results.add(map);
		}
		this.queryResult = results;
		
		
	}
	public ArrayList<Map<String,String>> getQueryResult(){
		return queryResult;
	}
	public DLquery(String substance, String dosages, String form, String route, String distinction, OWLReasoner reasoner,OWLOntology OCRx, OWLOntologyManager ontomanager,OWLDataFactory factory,OWLOntology OCRxWithAnnotation) {
		String RxCuisub = substance;
		String RxCuidosage = dosages;
		String RxCuiFo = form;
		String RxCuiRoa = route;
		String RxCuiDistinc = distinction;
		
		String query = "";
		if(!RxCuisub.equals("")) {
			if(RxCuidosage.equals("")) {
				if(RxCuiFo.equals("")) {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000007 some "+RxCuisub
									+")";
						}
						else {
							 query ="1000000000 and (7000000007 some "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000001 some "+RxCuiDistinc+"))";
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000007 some "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 some "+RxCuiRoa+"))";
							
						}
						else {
							 query ="1000000000 and (7000000007 some "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 some "+RxCuiRoa+")"
									+" and (7000000001 some "+RxCuiDistinc+")"
									+ ")";
						}
					}
				}
				else {
					
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000007 some "+RxCuisub
									 +") and (7000000008 some   "+RxCuiFo+ ")";
						}
						else {
							query ="1000000000 and (7000000007 some "+RxCuisub
									+") and 7000000008 some ( "+RxCuiFo
									+" and (7000000001 some "+RxCuiDistinc+"))";
						}
						
					}
					else {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000007 some "+RxCuisub
										+") and 7000000008 some (  "+RxCuiFo
										+" and (7000000002 some "+RxCuiRoa+"))";
						}
						else {
							 query ="1000000000 and (7000000007 some "+RxCuisub
										+") and 7000000008 some (  "+RxCuiFo
										+" and (7000000002 some "+RxCuiRoa+")"
										+" and (7000000001 some "+RxCuiDistinc+")"
										+ ")";
						}
					}
				}
			}
			else {
				
				if(RxCuiFo.equals("")) {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000007 some ("+RxCuisub
										+" and 7000000004 some "+RxCuidosage
										+ " ) )";
						}
						else {
							query ="1000000000 and (7000000007 some ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000001 some "+RxCuiDistinc+"))";
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							query ="1000000000 and (7000000007 some ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 some "+RxCuiRoa+"))";
						}
						else {
							query ="1000000000 and (7000000007 some ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 some "+RxCuiRoa+")"
									+" and (7000000001 some "+RxCuiDistinc+")"
									+ ")";
							
						}
					}
				}
				else {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							query ="1000000000 and (7000000007 some ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									 +") and (7000000008 some   "+RxCuiFo+ ")";
						}
						else {
							query ="1000000000 and (7000000007 some ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some (  "+RxCuiFo
									+" and (7000000001 some "+RxCuiDistinc+"))";
							
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							query ="1000000000 and (7000000007 some ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some (  "+RxCuiFo
									+" and (7000000002 some "+RxCuiRoa+"))";
						}
						else {
							query ="1000000000 and (7000000007 some ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some (   "+RxCuiFo
									+" and (7000000002 some "+RxCuiRoa+")"
									+" and (7000000001 some "+RxCuiDistinc+")"
									+ ")";
						}
					}
				}
			}
			
		}
		
		
		// System.out.pinrtln(query);
		
		ShortFormProvider prefixe = new SimpleShortFormProvider();
		OWLEntityChecker entityChecker = new ShortFormEntityChecker( new BidirectionalShortFormProviderAdapter(ontomanager,OCRx.getImportsClosure(), prefixe));// System.out.pinrtln(query);
		OWLClassExpression queryTest =DLquerySyntax(query, factory, entityChecker, OCRx);
		
		
		
		Set<OWLClass> resu2 =reasoner.getSubClasses(queryTest,false).getFlattened();
		Set<OWLClass> resu =reasoner.getEquivalentClasses(queryTest).getEntities();
		
		
	}
	private OWLClassExpression DLquerySyntax(String QueryInManchesterSyntax, OWLDataFactory ontologyFactory,OWLEntityChecker entityChecker, OWLOntology ontology) {
		//ManchesterOWLSyntaxParserImpl parser = new ManchesterOWLSyntaxParserImpl(new ontologycon, ontologyFactory)
		//parser.getPrefixManager().setDefaultPrefix("http://www.ocrx.ca/OCRx/");
		//ManchesterOWLSyntaxEditorParser parser = new ManchesterOWLSyntaxEditorParser(ontologyFactory, QueryInManchesterSyntax);
		ManchesterOWLSyntaxParser parser = OWLManager.createManchesterParser();
		parser.setDefaultOntology(ontology);
		parser.setOWLEntityChecker(entityChecker);
		parser.setStringToParse(QueryInManchesterSyntax);
		OWLClassExpression classeExpression=parser.parseClassExpression();
		return classeExpression;
	}
	public Set<RxClinicalDrug> getClinicaldrugs() {
		return clinicaldrugs;
	}
	public void setClinicaldrugs(Set<RxClinicalDrug> clinicaldrugs) {
		this.clinicaldrugs = clinicaldrugs;
	}

}
