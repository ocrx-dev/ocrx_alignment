package jn.ocrx.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.expression.OWLEntityChecker;
import org.semanticweb.owlapi.expression.ShortFormEntityChecker;
import org.semanticweb.owlapi.model.OWLAnnotationAssertionAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.search.EntitySearcher;
import org.semanticweb.owlapi.util.BidirectionalShortFormProviderAdapter;
import org.semanticweb.owlapi.util.DefaultPrefixManager;
import org.semanticweb.owlapi.util.ShortFormProvider;
import org.semanticweb.owlapi.util.SimpleShortFormProvider;
import org.semanticweb.owlapi.util.mansyntax.ManchesterOWLSyntaxParser;

public class DLqueryMultipleExact {
	private Set<RxClinicalDrug> clinicaldrugs;
	private Set<RxDefinitionaFeatures> definitional;
	
	public DLqueryMultipleExact(Set<String> substances, String dosages, String form, String route, String distinction, OWLReasoner reasoner,OWLOntology OCRx, OWLOntologyManager ontomanager,OWLDataFactory factory,OWLOntology OCRxWithAnnotation) {
		Set<String> RxCuisubs = substances;
		String RxCuidosage = dosages;
		String RxCuiFo = form;
		String RxCuiRoa = route;
		String RxCuiDistinc = distinction;
		
		PrefixManager pm= new DefaultPrefixManager("http://www.ocrx.ca/OCRx/");
		Map<String, Set<OWLAnnotationAssertionAxiom>  >AnnotationSubstances = new HashMap<String, Set<OWLAnnotationAssertionAxiom>>();
		for(String RxCuisub:RxCuisubs) {
			OWLClass SubsClass = factory.getOWLClass(RxCuisub, pm);
			Set<OWLAnnotationAssertionAxiom> AnnotationSubstance = new HashSet<OWLAnnotationAssertionAxiom>();
			
		
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(SubsClass, OCRxWithAnnotation)) {
				AnnotationSubstance.add(ax);
			}
			if(!AnnotationSubstances.containsKey(RxCuisub)) {
				AnnotationSubstances.put(RxCuisub, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			AnnotationSubstances.get(RxCuisub).addAll(AnnotationSubstance);
		
		}
		Set<OWLAnnotationAssertionAxiom> AnnotationRouteOfAdministration = new HashSet<OWLAnnotationAssertionAxiom>();
		Set<OWLAnnotationAssertionAxiom> AnnotationFormes = new HashSet<OWLAnnotationAssertionAxiom>();
		if(!RxCuiRoa.equals("")) {
			OWLClass RoaClass = factory.getOWLClass(RxCuiRoa, pm);
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(RoaClass, OCRxWithAnnotation)) {
				AnnotationRouteOfAdministration.add(ax);
			}
		}
		
		if(!RxCuiFo.equals("")) {			
			OWLClass FoClass = factory.getOWLClass(RxCuiFo, pm);
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(FoClass, OCRxWithAnnotation)) {
				AnnotationFormes.add(ax);
			}
		}
		
		
		
		
		String MainClinical ="";
		
		String query = "";
		
			MainClinical = getMainFromSet(RxCuisubs);
		
		
		String RxCuisub=getSubstanceFromSet(RxCuisubs);
		
		if(!RxCuisub.equals("")) {
			if(RxCuidosage.equals("")) {
				if(RxCuiFo.equals("")) {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query =MainClinical+" and (7000000006 only "+RxCuisub
									+")";
						}
						else {
							 query =MainClinical+" and (7000000006 only "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000001 only "+RxCuiDistinc+"))";
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							 query =MainClinical+"and (7000000006 only "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 only "+RxCuiRoa+"))";
							
						}
						else {
							 query =MainClinical+"and (7000000006 only "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 only "+RxCuiRoa+")"
									+" and (7000000001 only "+RxCuiDistinc+")"
									+ ")";
						}
					}
				}
				else {
					
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query =MainClinical+"and (7000000006 only "+RxCuisub
									 +") and (7000000008 only   "+RxCuiFo+ ")";
						}
						else {
							query =MainClinical+"and (7000000006 only "+RxCuisub
									+") and 7000000008 only ( "+RxCuiFo
									+" and (7000000001 only "+RxCuiDistinc+"))";
						}
						
					}
					else {
						if(RxCuiDistinc.equals("")) {
							 query =MainClinical+"and (7000000006 only "+RxCuisub
										+") and 7000000008 only (  "+RxCuiFo
										+" and (7000000002 only "+RxCuiRoa+"))";
						}
						else {
							 query =MainClinical+"and (7000000006 only "+RxCuisub
										+") and 7000000008 only (  "+RxCuiFo
										+" and (7000000002 only "+RxCuiRoa+")"
										+" and (7000000001 only "+RxCuiDistinc+")"
										+ ")";
						}
					}
				}
			}
			else {
				
				if(RxCuiFo.equals("")) {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query =MainClinical+"and (7000000006 only ("+RxCuisub
										+" and 7000000004 some "+RxCuidosage
										+ " ) )";
						}
						else {
							query =MainClinical+"and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000001 only "+RxCuiDistinc+"))";
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							query =MainClinical+"and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 only "+RxCuiRoa+"))";
						}
						else {
							query =MainClinical+"and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 only "+RxCuiRoa+")"
									+" and (7000000001 only "+RxCuiDistinc+")"
									+ ")";
							
						}
					}
				}
				else {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							query =MainClinical+"and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									 +") and (7000000008 only   "+RxCuiFo+ ")";
						}
						else {
							query =MainClinical+"and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 only (  "+RxCuiFo
									+" and (7000000001 only "+RxCuiDistinc+"))";
							
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							query =MainClinical+"and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 only (  "+RxCuiFo
									+" and (7000000002 only "+RxCuiRoa+"))";
						}
						else {
							query =MainClinical+"and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 only (   "+RxCuiFo
									+" and (7000000002 only "+RxCuiRoa+")"
									+" and (7000000001 only "+RxCuiDistinc+")"
									+ ")";
						}
					}
				}
			}
			
		}
		
		
		// System.out.pinrtln(query);
		
		ShortFormProvider prefixe = new SimpleShortFormProvider();
		OWLEntityChecker entityChecker = new ShortFormEntityChecker( new BidirectionalShortFormProviderAdapter(ontomanager,OCRx.getImportsClosure(), prefixe));// System.out.pinrtln(query);
		OWLClassExpression qeryTest =DLqeriSyntax(query, factory, entityChecker, OCRx);
		
		
		
		Set<OWLClass> resu2 =reasoner.getSubClasses(qeryTest,false).getFlattened();
		Set<OWLClass> resu =reasoner.getEquivalentClasses(qeryTest).getEntities();
		
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> equivalentClinicaldrugs = new HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> SubclassClinicaldrugs = new  HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		
		for(OWLClass eq : resu) {
			if(!equivalentClinicaldrugs.containsKey(eq)) {
				equivalentClinicaldrugs.put(eq, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(eq, OCRxWithAnnotation)) {
				equivalentClinicaldrugs.get(eq).add(ax);
			}
		}
		for(OWLClass sub : resu2) {
			if(!SubclassClinicaldrugs.containsKey(sub)) {
				SubclassClinicaldrugs.put(sub, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(sub, OCRxWithAnnotation)) {
				SubclassClinicaldrugs.get(sub).add(ax);
			}
		}
		
		Set<RxDefinitionaFeatures> def = new HashSet<RxDefinitionaFeatures>();
		for(String Subs : AnnotationSubstances.keySet()) {
			RxDefinitionaFeatures subs = new RxDefinitionaFeatures(AnnotationSubstances.get(Subs), Subs, "Substance");
			def.add(subs);
		}
		
		RxDefinitionaFeatures forms = new RxDefinitionaFeatures(AnnotationFormes, RxCuiFo, "Form");
		RxDefinitionaFeatures RoA = new RxDefinitionaFeatures(AnnotationRouteOfAdministration, RxCuiRoa, " Route of Administration");
		def.add(RoA);
		
		def.add(forms);
		Set<RxClinicalDrug> CanadianClinicalDrug = new HashSet<RxClinicalDrug>();
		
		for(OWLClass cal : SubclassClinicaldrugs.keySet()) {
			String ccd = cal.getIRI().getShortForm();
			if(!ccd.equals("Nothing")) {
					Set<OWLAnnotationAssertionAxiom> annotation =SubclassClinicaldrugs.get(cal);
					RxClinicalDrug cc = new RxClinicalDrug(annotation, ccd, "SUB_Class");
					CanadianClinicalDrug.add(cc);
			}
		}
		
		for(OWLClass cal : equivalentClinicaldrugs.keySet()) {
			String ccd = cal.getIRI().getShortForm();
			if(!ccd.equals("Nothing")) {
					Set<OWLAnnotationAssertionAxiom> annotation =equivalentClinicaldrugs.get(cal);
					RxClinicalDrug cc = new RxClinicalDrug(annotation, ccd, "Equivalent");
					CanadianClinicalDrug.add(cc);
			}
		}
	
		this.setClinicaldrugs(CanadianClinicalDrug);
		this.setDefinitional(def);
		
		
	}
	private OWLClassExpression DLqeriSyntax(String QueryInManchesterSyntax, OWLDataFactory ontologyFactory,OWLEntityChecker entityChecker, OWLOntology ontology) {
		//ManchesterOWLSyntaxParserImpl parser = new ManchesterOWLSyntaxParserImpl(new ontologycon, ontologyFactory)
		//parser.getPrefixManager().setDefaultPrefix("http://www.ocrx.ca/OCRx/");
		//ManchesterOWLSyntaxEditorParser parser = new ManchesterOWLSyntaxEditorParser(ontologyFactory, QueryInManchesterSyntax);
		ManchesterOWLSyntaxParser parser = OWLManager.createManchesterParser();
		parser.setDefaultOntology(ontology);
		parser.setOWLEntityChecker(entityChecker);
		parser.setStringToParse(QueryInManchesterSyntax);
		OWLClassExpression classeExpression=parser.parseClassExpression();
		return classeExpression;
	}
	public Set<RxClinicalDrug> getClinicaldrugs() {
		return clinicaldrugs;
	}
	public void setClinicaldrugs(Set<RxClinicalDrug> clinicaldrugs) {
		this.clinicaldrugs = clinicaldrugs;
	}
	
	public String getSubstanceFromSet(Set<String> RxCuisubs) {

		String Substance="";
		if(RxCuisubs.size()==1) {
			for(String subs : RxCuisubs) {
				Substance=subs;
			}
		}
		else {
			int ui= 1;
			
			for(String subs : RxCuisubs) {
				if(ui==1) {
					Substance=subs;
					ui++;
				}
				else {
					Substance=Substance+" and "+subs;
					ui++;
				}
			}
			Substance="( "+Substance+" )";
			
			
		}
		return Substance;
	}
	
	
	public String getMainFromSet(Set<String>RxCuisubs) {
		String MainClinical="";
		if(RxCuisubs.size()==1) {
			MainClinical="1100000000";
		}
		else if(RxCuisubs.size()==2) {
			MainClinical="1200000002";
		}
		else if(RxCuisubs.size()==3) {
			MainClinical="1200000003";
		}
		else if(RxCuisubs.size()==4) {
			MainClinical="1200000004";
		}
		else if(RxCuisubs.size()==5) {
			MainClinical="1200000005";
		}
		else if(RxCuisubs.size()==6) {
			MainClinical="1200000006";
		}
		else if(RxCuisubs.size()==7) {
			MainClinical="1200000007";
		}
		else if(RxCuisubs.size()==8) {
			MainClinical="1200000008";
		}
		else if(RxCuisubs.size()==9) {
			MainClinical="1200000009";
		}
		else if(RxCuisubs.size()==10) {
			MainClinical="1200000010";
		}
		
		else {
			
			MainClinical="10000000"+RxCuisubs.size();
		}
		return MainClinical;
	}
	public Set<RxDefinitionaFeatures> getDefinitional() {
		return definitional;
	}
	public void setDefinitional(Set<RxDefinitionaFeatures> definitional) {
		this.definitional = definitional;
	}

}
