package jn.ocrx.singleton;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AutoCompleteLabel {

	private Set<String> substances;
	private Set<String> form;
	private Set<String> routeAdmin;
	
	public AutoCompleteLabel() {
		this.substances=new HashSet<String>();
		this.form=new HashSet<String>();
		this.routeAdmin=new HashSet<String>();
	}
	
	public List<String> getLabel(String key) {
		
		switch (key) {
		case "substances": 
			
			return new ArrayList<String>(this.substances);
		
		case "forms":
			return new ArrayList<String>(this.form);
		
		case "routes of administration":
			return new ArrayList<String>(this.routeAdmin);
		
		default:
			throw new IllegalArgumentException("Unexpected value: " + key);
		}
	}
	
	public void setLabel(String key, String label) {
		
		switch (key) {
		case "substances": 
			
			this.substances.add(label);
			break;
		
		case "forms":
			this.form.add(label);
			break;
		
		case "routes of administration":
			this.routeAdmin.add(label);
			break;
		
		default:
			throw new IllegalArgumentException("Unexpected value: " + key);
		}
	}
	
    public void setSeveralLabel(String key, List<String> labels) {
		
		switch (key) {
		case "substances": 
			
			this.substances.addAll(labels);
			break;
		
		case "forms":
			this.form.addAll(labels);
			break;
		
		case "routes of administration":
			this.routeAdmin.addAll(labels);
			break;
		
		default:
			throw new IllegalArgumentException("Unexpected value: " + key);
		}
	}
	
	
	
}
