package jn.ocrx.core;

import java.io.File;
import java.io.PrintWriter;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLAnnotationAssertionAxiom;
import org.semanticweb.owlapi.model.OWLAnnotationValue;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.search.EntitySearcher;

import flexjson.JSONSerializer;
import jn.ocrx.singleton.infoDataBase;

public class QueryFact {
	
	
	public static Set<RxClinicalDrug> queryRXC(String label) {
		label=label.toUpperCase();
		OWLDataFactory factory = infoDataBase.geODF();
		OWLLiteral lit= factory.getOWLLiteral("label", "en");
		OWLAnnotation annlit = factory.getOWLAnnotation(factory.getRDFSLabel(), lit);
		Set<OWLClass> resut = new HashSet<>();
		
		OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
		for(OWLClass cls : OCRx2.getClassesInSignature()) {
			for(OWLAnnotation annotation : EntitySearcher.getAnnotations(cls, OCRx2)) {
				if(annotation.equals(annlit)) {
					resut.add(cls);
				}
			}
		}
		
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> equivalentRx= new HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		for(OWLClass eq : resut) {
			if(!equivalentRx.containsKey(eq)) {
				equivalentRx.put(eq, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(eq, OCRx2)) {
				equivalentRx.get(eq).add(ax);
			}
		}
		 Set<RxClinicalDrug>  resy = new HashSet();
		for(OWLClass cal : equivalentRx.keySet()) {
			String ccd = cal.getIRI().getShortForm();
					Set<OWLAnnotationAssertionAxiom> annotation =equivalentRx.get(cal);
					RxClinicalDrug Rx = new RxClinicalDrug(annotation, label, "Equivalent");
					resy.add(Rx);
		}
		
		return resy;
	}
	
	public static Set<RxConceptGeneral> query(String label, String TTY) {
		label=label.toUpperCase();
		OWLDataFactory factory = infoDataBase.geODF();
		OWLLiteral lit= factory.getOWLLiteral("label", "en");
		OWLAnnotation annlit = factory.getOWLAnnotation(factory.getRDFSLabel(), lit);
		Set<OWLClass> resut = new HashSet<>();
		
		OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
		for(OWLClass cls : OCRx2.getClassesInSignature()) {
			for(OWLAnnotation annotation : EntitySearcher.getAnnotations(cls, OCRx2)) {
				if(annotation.equals(annlit)) {
					resut.add(cls);
				}
			}
		}
		
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> equivalentRx= new HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		for(OWLClass eq : resut) {
			if(!equivalentRx.containsKey(eq)) {
				equivalentRx.put(eq, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(eq, OCRx2)) {
				equivalentRx.get(eq).add(ax);
			}
		}
		 Set<RxConceptGeneral>  resy = new HashSet();
		for(OWLClass cal : equivalentRx.keySet()) {
			String ccd = cal.getIRI().getShortForm();
					Set<OWLAnnotationAssertionAxiom> annotation =equivalentRx.get(cal);
					if(ccd.startsWith("40")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"FORM");
						if(TTY.equals("FORM")) {
							resy.add(Rx);
						}
					}
					if(ccd.startsWith("42")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"DISTINCTION");
						if(TTY.equals("DISTINCTION")) {
						resy.add(Rx);
						}
					}
					if(ccd.startsWith("41")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"ROAD");
						if(TTY.equals("ROAD")) {
							resy.add(Rx);
							}
					}
					if(ccd.startsWith("3")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"SUBSTANCE");
						if(TTY.equals("SUBSTANCE")) {
							resy.add(Rx);
							}
					}
					if(ccd.startsWith("S")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"DOSAGE");
						if(TTY.equals("DOSAGE")) {
							resy.add(Rx);
							}
					}
					if(ccd.startsWith("2")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"COMPONENT");
						if(TTY.equals("COMPONENT")) {
							resy.add(Rx);
							}
					}
					if(ccd.startsWith("1")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"CCD");
						if(TTY.equals("CCD")) {
							resy.add(Rx);
							}
					}
		}
		
		return resy;
	}
	public static Set<RxConceptGeneral> query(String label) {
		label=label.toUpperCase();
		OWLDataFactory factory = infoDataBase.geODF();
		OWLLiteral lit= factory.getOWLLiteral("label", "en");
		OWLAnnotation annlit = factory.getOWLAnnotation(factory.getRDFSLabel(), lit);
		Set<OWLClass> resut = new HashSet<>();
		
		OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
		for(OWLClass cls : OCRx2.getClassesInSignature()) {
			for(OWLAnnotation annotation : EntitySearcher.getAnnotations(cls, OCRx2)) {
				if(annotation.equals(annlit)) {
					resut.add(cls);
				}
			}
		}
		
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> equivalentRx= new HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		for(OWLClass eq : resut) {
			if(!equivalentRx.containsKey(eq)) {
				equivalentRx.put(eq, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(eq, OCRx2)) {
				equivalentRx.get(eq).add(ax);
			}
		}
		 Set<RxConceptGeneral>  resy = new HashSet<>();
		for(OWLClass cal : equivalentRx.keySet()) {
			String ccd = cal.getIRI().getShortForm();
					Set<OWLAnnotationAssertionAxiom> annotation =equivalentRx.get(cal);
					if(ccd.startsWith("40")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"FORM");
						resy.add(Rx);
					}
					if(ccd.startsWith("42")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"DISTINCTION");
						resy.add(Rx);
					}
					if(ccd.startsWith("41")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"ROAD");
						resy.add(Rx);
					}
					if(ccd.startsWith("3")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"SUBSTANCE");
						resy.add(Rx);
					}
					if(ccd.startsWith("S")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"DOSAGE");
						resy.add(Rx);
					}
					if(ccd.startsWith("2")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"COMPONENT");
						resy.add(Rx);
					}
					if(ccd.startsWith("1")) {
						RxConceptGeneral Rx = new RxConceptGeneral(annotation, ccd,"CCD");
						resy.add(Rx);
					}
		}
		
		return resy;
	}
	
	
	public static String queryExact(String substance, String dosage, String form, String route, String distinction) throws OWLOntologyCreationException {
		// System.out.pinrtln("query");
			Instant start1= Instant.now();
			OWLReasoner reasoner = infoDataBase.getReasonerT();
			OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
			OWLOntology OCRx = infoDataBase.getOntologyT("without");
			OWLOntologyManager	ontomanager = infoDataBase.getOM();
		 	OWLDataFactory factory = infoDataBase.geODF();
		 	DLqueryExact as = new DLqueryExact( substance,  dosage,  form,  route,  distinction,  reasoner, OCRx, ontomanager, factory,OCRx2);	
			Instant end1= Instant.now();
			// System.out.pinrtln("DLquerie duration "+Duration.between(start1, end1));
			
			List<Map<String,Object>> clinicaldrugs = new ArrayList<>();
			for(RxClinicalDrug rcd : as.getClinicaldrugs()) {
				Map<String,Object> oneRcd  =	new HashMap<>();
				oneRcd.put("RxCui", rcd.getRxCui());
				oneRcd.put("BrandedIDs", new ArrayList<>(rcd.getDIN()));
				oneRcd.put("labels", new ArrayList<>(rcd.getConcept().getSTR()));
				oneRcd.put("Comment", rcd.getConcept().getComment());
				oneRcd.put("TTY", rcd.getTTY());
				List<Map<String,String>> listObj = new ArrayList<>();
				for(RxMapping rxm : rcd.getMappings()) {
					Map<String,String> m = new HashMap<>();
					m.put("XREF", rxm.getXREF());
					m.put("Source", rxm.getSOURCE());
					m.put("Type", rxm.getSOURCETYPE());
					listObj.add(m);
				}
				oneRcd.put("Mapping", listObj);	
				clinicaldrugs.add(oneRcd);
			}
			
			Map<String,Object> res = new HashMap<>();
			
			res.put("CCD", clinicaldrugs);
			JSONObject jo = new JSONObject();
			jo.putAll(res);
			String json =  jo.toJSONString();
			return json;
	
	}
	public static String queryDirect(String query) throws OWLOntologyCreationException {
		// System.out.pinrtln("query");
			Instant start1= Instant.now();
			OWLReasoner reasoner = infoDataBase.getReasonerT();
			// OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
			OWLOntology OCRx = infoDataBase.getOntologyT("without");
			OWLOntologyManager	ontomanager = infoDataBase.getOM();
		 	OWLDataFactory factory = infoDataBase.geODF();
		 	DLquery as = new DLquery(query,  reasoner, OCRx, ontomanager, factory);	
			Instant end1= Instant.now();
			JSONSerializer serializer = new JSONSerializer();
			String json = serializer.serialize(as.getQueryResult());

			// jo.putAll(as.getQueryResult());
			// String json =  jo.toJSONString();
			
			System.out.println("Time taken:" + Duration.between(start1, end1));
			return json;
	
	}
	public static String query(String substance, String dosage, String form, String route, String distinction) throws OWLOntologyCreationException {
		// System.out.pinrtln("query");
			Instant start1= Instant.now();
			OWLReasoner reasoner = infoDataBase.getReasonerT();
			OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
			OWLOntology OCRx = infoDataBase.getOntologyT("without");
			OWLOntologyManager	ontomanager = infoDataBase.getOM();
		 	OWLDataFactory factory = infoDataBase.geODF();
		 	DLquery as = new DLquery( substance,  dosage,  form,  route,  distinction,  reasoner, OCRx, ontomanager, factory,OCRx2);	
			Instant end1= Instant.now();
			// System.out.pinrtln("DLquerie duration "+Duration.between(start1, end1));
			
			List<Map<String,Object>> clinicaldrugs = new ArrayList<>();
			for(RxClinicalDrug rcd : as.getClinicaldrugs()) {
				Map<String,Object> oneRcd  =	new HashMap<>();
				oneRcd.put("RxCui", rcd.getRxCui());
				oneRcd.put("BrandedIDs", new ArrayList<>(rcd.getDIN()));
				oneRcd.put("labels", new ArrayList<>(rcd.getConcept().getSTR()));
				oneRcd.put("Comment", rcd.getConcept().getComment());
				oneRcd.put("TTY", rcd.getTTY());
				List<Map<String,String>> listObj = new ArrayList<>();
				for(RxMapping rxm : rcd.getMappings()) {
					Map<String,String> m = new HashMap<>();
					m.put("XREF", rxm.getXREF());
					m.put("Source", rxm.getSOURCE());
					m.put("Type", rxm.getSOURCETYPE());
					listObj.add(m);
				}
				oneRcd.put("Mapping", listObj);	
				clinicaldrugs.add(oneRcd);
			}
			
			Map<String,Object> res = new HashMap<>();
			res.put("CCD", clinicaldrugs);
			JSONObject jo = new JSONObject();
			jo.putAll(res);
			String json =  jo.toJSONString();
			return json;
	
	}
	
	
public static String queryMOnly(String[] s, String f, String r) throws OWLOntologyCreationException {

		
		Set<String> RxCuiSubstances= new HashSet<String>(Arrays.asList(s)); 
		String RxCuiForm=f;
		String RxCuiROAD=r;
		// System.out.pinrtln("query");
		Instant start1= Instant.now();
		OWLReasoner reasoner = infoDataBase.getReasonerT();
		OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
		OWLOntology OCRx = infoDataBase.getOntologyT("without");
		OWLOntologyManager	ontomanager = infoDataBase.getOM();
		 OWLDataFactory factory = infoDataBase.geODF();
		 DLqueryMultipleExact as = new DLqueryMultipleExact(RxCuiSubstances,"", RxCuiForm, "",RxCuiROAD, reasoner, OCRx, ontomanager, factory,OCRx2);				 
		Instant end1= Instant.now();
		// System.out.pinrtln("DLquerie duration "+Duration.between(start1, end1));
		
		
		List<Map<String,Object>> clinicaldrugs = new ArrayList<>();
		for(RxClinicalDrug rcd : as.getClinicaldrugs()) {
			Map<String,Object> oneRcd  =	new HashMap<>();
			oneRcd.put("RxCui", rcd.getRxCui());
			oneRcd.put("BrandedIDs", new ArrayList<>(rcd.getDIN()));
			oneRcd.put("labels", new ArrayList<>(rcd.getConcept().getSTR()));
			oneRcd.put("Comment", rcd.getConcept().getComment());
			oneRcd.put("TTY", rcd.getTTY());
			List<Map<String,String>> listObj = new ArrayList<>();
			for(RxMapping rxm : rcd.getMappings()) {
				Map<String,String> m = new HashMap<>();
				m.put("XREF", rxm.getXREF());
				m.put("Source", rxm.getSOURCE());
				m.put("Type", rxm.getSOURCETYPE());
				listObj.add(m);
			}
			oneRcd.put("Mapping", listObj);	
			clinicaldrugs.add(oneRcd);
		}
		
		List<Map<String,Object>> definitional = new ArrayList<>();
		for(RxDefinitionaFeatures rcd : as.getDefinitional()) {
			Map<String,Object> oneRcd  =	new HashMap<>();
			oneRcd.put("RxCui", rcd.getRxCui());
			oneRcd.put("labels", new ArrayList<>(rcd.getConcept().getSTR()));
			oneRcd.put("Comment", rcd.getConcept().getComment());
			oneRcd.put("TTY", rcd.getTTY());
			List<Map<String,String>> listObj = new ArrayList<>();
			for(RxMapping rxm : rcd.getMappings()) {
				Map<String,String> m = new HashMap<>();
				m.put("XREF", rxm.getXREF());
				m.put("Source", rxm.getSOURCE());
				m.put("Type", rxm.getSOURCETYPE());
				listObj.add(m);
			}
			oneRcd.put("Mapping", listObj);	
			definitional.add(oneRcd);
		}
		
		Map<String,Object> res = new HashMap<>();
		res.put("clinic", clinicaldrugs);
		res.put("def", definitional);
		JSONObject jo = new JSONObject();
		jo.putAll(res);
		String json =  jo.toJSONString();
		
//		1000000052 1000001242 1000004813 1000005026 1000005947 1000006813 1000007010 1000007967 1000008169 1000009689 1000010934 1000011683 1000012970 1000013434 1000016311 1000016493 1000017305 1000018560 1000019068 1000023084 1000023293 1000024663 1000026768 1000026799 
		// SUB_Class or equivalent
		return json;


	}
public static String queryM(String[] s, String f, String r, String NbrExact) throws OWLOntologyCreationException {

		
		Set<String> RxCuiSubstances= new HashSet<String>(Arrays.asList(s)); 
		String RxCuiForm=f;
		String RxCuiROAD=r;
		if(RxCuiROAD.equals("-")) {
			RxCuiROAD="";
		}
		if(RxCuiForm.equals("-")) {
			RxCuiForm="";
		}
		// System.out.pinrtln("query");
		Instant start1= Instant.now();
		OWLReasoner reasoner = infoDataBase.getReasonerT();
		OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
		OWLOntology OCRx = infoDataBase.getOntologyT("without");
		OWLOntologyManager	ontomanager = infoDataBase.getOM();
		 OWLDataFactory factory = infoDataBase.geODF();
		 // System.out.pinrtln("NbrExact "+NbrExact);
		 DLqueryMultiple as = new DLqueryMultiple(RxCuiSubstances,"", RxCuiForm, RxCuiROAD,"", reasoner, OCRx, ontomanager, factory,OCRx2,NbrExact);				 
		Instant end1= Instant.now();
		// System.out.pinrtln("DLquerie duration "+Duration.between(start1, end1));
		
		
		List<Map<String,Object>> clinicaldrugs = new ArrayList<>();
		for(RxClinicalDrug rcd : as.getClinicaldrugs()) {
			Map<String,Object> oneRcd  =	new HashMap<>();
			oneRcd.put("RxCui", rcd.getRxCui());
			oneRcd.put("BrandedIDs", new ArrayList<>(rcd.getDIN()));
			oneRcd.put("labels", new ArrayList<>(rcd.getConcept().getSTR()));
			oneRcd.put("Comment", rcd.getConcept().getComment());
			oneRcd.put("TTY", rcd.getTTY());
			List<Map<String,String>> listObj = new ArrayList<>();
			for(RxMapping rxm : rcd.getMappings()) {
				Map<String,String> m = new HashMap<>();
				m.put("XREF", rxm.getXREF());
				m.put("Source", rxm.getSOURCE());
				m.put("Type", rxm.getSOURCETYPE());
				listObj.add(m);
			}
			oneRcd.put("Mapping", listObj);	
			clinicaldrugs.add(oneRcd);
		}
		
		List<Map<String,Object>> definitional = new ArrayList<>();
		for(RxDefinitionaFeatures rcd : as.getDefinitional()) {
			Map<String,Object> oneRcd  =	new HashMap<>();
			oneRcd.put("RxCui", rcd.getRxCui());
			oneRcd.put("labels", new ArrayList<>(rcd.getConcept().getSTR()));
			oneRcd.put("Comment", rcd.getConcept().getComment());
			oneRcd.put("TTY", rcd.getTTY());
			List<Map<String,String>> listObj = new ArrayList<>();
			for(RxMapping rxm : rcd.getMappings()) {
				Map<String,String> m = new HashMap<>();
				m.put("XREF", rxm.getXREF());
				m.put("Source", rxm.getSOURCE());
				m.put("Type", rxm.getSOURCETYPE());
				listObj.add(m);
			}
			oneRcd.put("Mapping", listObj);	
			definitional.add(oneRcd);
		}
		
		Map<String,Object> res = new HashMap<>();
		res.put("clinic", clinicaldrugs);
		res.put("def", definitional);
		
		JSONObject jo = new JSONObject();
		jo.putAll(res);
		String json =  jo.toJSONString();
		
//		1000000052 1000001242 1000004813 1000005026 1000005947 1000006813 1000007010 1000007967 1000008169 1000009689 1000010934 1000011683 1000012970 1000013434 1000016311 1000016493 1000017305 1000018560 1000019068 1000023084 1000023293 1000024663 1000026768 1000026799 
		// SUB_Class or equivalent
		return json;


	}
	
	public static String queryAnalysis(String s, String f, String r) throws OWLOntologyCreationException {

		
		String RxCuiSubstance=s; 
		String RxCuiForm=f;
		String RxCuiROAD=r;
		// System.out.pinrtln("query");
		Instant start1= Instant.now();
		OWLReasoner reasoner = infoDataBase.getReasonerT();
		OWLOntology OCRx2 = infoDataBase.getOntologyT("with");
		OWLOntology OCRx = infoDataBase.getOntologyT("without");
		OWLOntologyManager	ontomanager = infoDataBase.getOM();
		 OWLDataFactory factory = infoDataBase.geODF();
		DBmanager as = new DBmanager(RxCuiSubstance, RxCuiForm, RxCuiROAD, reasoner, OCRx, ontomanager, factory,OCRx2);	
		Instant end1= Instant.now();
		// System.out.pinrtln("DLquerie duration "+Duration.between(start1, end1));
		
		
		List<Map<String,Object>> clinicaldrugs = new ArrayList<>();
		for(RxClinicalDrug rcd : as.clinicaldrugs) {
			Map<String,Object> oneRcd  =	new HashMap<>();
			oneRcd.put("RxCui", rcd.getRxCui());
			oneRcd.put("BrandedIDs", new ArrayList<>(rcd.getDIN()));
			oneRcd.put("labels", new ArrayList<>(rcd.getConcept().getSTR()));
			oneRcd.put("Comment", rcd.getConcept().getComment());
			List<Map<String,String>> listObj = new ArrayList<>();
			for(RxMapping rxm : rcd.getMappings()) {
				Map<String,String> m = new HashMap<>();
				m.put("XREF", rxm.getXREF());
				m.put("Source", rxm.getSOURCE());
				m.put("Type", rxm.getSOURCETYPE());
				listObj.add(m);
			}
			oneRcd.put("Mapping", listObj);	
			clinicaldrugs.add(oneRcd);
		}
		List<Map<String,Object>> definitional = new ArrayList<>();
		for(RxDefinitionaFeatures rcd : as.definitional) {
			Map<String,Object> oneRcd  =	new HashMap<>();
			oneRcd.put("RxCui", rcd.getRxCui());
			oneRcd.put("labels", new ArrayList<>(rcd.getConcept().getSTR()));
			oneRcd.put("Comment", rcd.getConcept().getComment());
			oneRcd.put("TTY", rcd.getTTY());
			List<Map<String,String>> listObj = new ArrayList<>();
			for(RxMapping rxm : rcd.getMappings()) {
				Map<String,String> m = new HashMap<>();
				m.put("XREF", rxm.getXREF());
				m.put("Source", rxm.getSOURCE());
				m.put("Type", rxm.getSOURCETYPE());
				listObj.add(m);
			}
			oneRcd.put("Mapping", listObj);	
			definitional.add(oneRcd);
		}
		
		Map<String,Object> res = new HashMap<>();
		res.put("clinic", clinicaldrugs);
		res.put("def", definitional);
		JSONObject jo = new JSONObject();
		jo.putAll(res);
		String json =  jo.toJSONString();
		
//		1000000052 1000001242 1000004813 1000005026 1000005947 1000006813 1000007010 1000007967 1000008169 1000009689 1000010934 1000011683 1000012970 1000013434 1000016311 1000016493 1000017305 1000018560 1000019068 1000023084 1000023293 1000024663 1000026768 1000026799 
		// SUB_Class or equivalent
		return json;


	}

}
