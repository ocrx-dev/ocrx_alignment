package jn.ocrx.singleton;

import java.io.File;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.mindswap.pellet.jena.PelletReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import org.semanticweb.elk.owlapi.ElkReasonerFactory;
import uk.ac.manchester.cs.factplusplus.owlapiv3.FaCTPlusPlusReasonerFactory;

public class infoDataBase {

	private static AutoCompleteLabel labels;
	private static OWLOntologyManager ontomanager = OWLManager.createOWLOntologyManager();
	private static OWLOntologyManager ontomanager2 = OWLManager.createOWLOntologyManager();
	private static OWLDataFactory factory = ontomanager.getOWLDataFactory();
	private static OWLOntology OCRx;
	private static OWLOntology OCRx2;
	private static OWLReasoner reasoner;
	private static OntologyUtils Utils;

	public static void initializeReasoner() throws OWLOntologyCreationException {

		Utils = new OntologyUtils();
		File OntologyPath = new File("src/main/resources/static/ontologies/rxnorm.owl");
		// File OntologyPath2 = new File("src/main/resources/static/ontologies/OCRx.owl");
		OCRx = ontomanager.loadOntologyFromOntologyDocument(OntologyPath);
		// OCRx2 = ontomanager2.loadOntologyFromOntologyDocument(OntologyPath2);

		// System.out.pinrtln("reasoner");
		reasoner = new ElkReasonerFactory().createReasoner(OCRx);
		Instant start = Instant.now();
		// System.out.pinrtln(System.getProperty("java.library.path"));
		reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
		// ;
		Instant end = Instant.now();
		System.out.println("Finished! : "+Duration.between(start, end));
		Utils.setOCRx(OCRx);
		// Utils.setOCRx2(OCRx2);
		Utils.setReasoner(reasoner);
		System.out.println("Finished reasoner!");
	}

	// public static void initializeOrGet(List<Basicdoseform> bdfRepository,
	// List<Routeofadministration> roaRepository,
	// List<Substance> substanceRepository,
	// List<Substancetlabel> sublabelRepository,
	// List<Form> formRepository) throws OWLOntologyCreationException {
	//
	//
	// labels = new AutoCompleteLabel();
	// Utils = new OntologyUtils();
	// for(Basicdoseform bdf : bdfRepository) {
	// labels.setLabel("forms",bdf.getLabel().toUpperCase());
	// }
	// for(Form f : formRepository) {
	// labels.setLabel("forms",f.getLabel().toUpperCase());
	// }
	// for(Routeofadministration roa : roaRepository) {
	// labels.setLabel("routes of administration",roa.getLabel().toUpperCase());
	// }
	// for(Substance sub : substanceRepository) {
	// labels.setLabel("substances",sub.getLabel().toUpperCase());
	// }
	// for(Substancetlabel sub : sublabelRepository) {
	// labels.setLabel("substances",sub.getLabel().toUpperCase());
	// }
	//
	//
	// }

	public static OWLReasoner getReasonerT() {
		// System.out.pinrtln(Utils.getReasoner().getReasonerName());
		return Utils.getReasoner();
	}

	public static OWLOntology getOntologyT(String type) {

		switch (type) {
			case "with":
				return Utils.getOCRx2();
			case "without":
				return Utils.getOCRx();

			default:
				throw new IllegalArgumentException("Unexpected value: " + type);
		}

	}

	public static List<String> getLabels(String type) {

		return labels.getLabel(type);

	}

	public static OWLReasoner getReasoner() {
		// // System.out.pinrtln(reasoner.getReasonerName());
		return reasoner;
	}

	public static OWLOntology getOntology(String type) {

		switch (type) {
			case "with":
				return OCRx2;
			case "without":
				return OCRx;

			default:
				throw new IllegalArgumentException("Unexpected value: " + type);
		}

	}

	public static OWLOntologyManager getOM() {
		return ontomanager;
	}

	public static OWLDataFactory geODF() {
		return factory;
	}

	public void disposeReasoner() {
		synchronized (this) {
			if (reasoner != null) {
				reasoner.dispose();
				reasoner = null;
			}
			CompletableFuture.supplyAsync(() -> {
				// load ontology from file
				OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
				OWLOntology ontology = null;
				try {
					File OntologyPath = new File("src/main/resources/static/ontologies/OCRxWithoutAnnotation.owl");
					ontology = manager.loadOntologyFromOntologyDocument(OntologyPath);
				} catch (OWLOntologyCreationException e) {
					// handle exception
				}
				// create reasoner and classify ontology
				reasoner = new FaCTPlusPlusReasonerFactory().createReasoner(OCRx);
				// Instant start = Instant.now();
				// System.out.pinrtln(System.getProperty("java.library.path"));
				// reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
				// OWLReasonerFactory reasonerFactory = FaCTPlusPlusReasonerFactory.getInstance();
				// OWLReasoner reasoner = reasonerFactory.createReasoner(ontology);
				reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
				return reasoner;
			}).thenAcceptAsync(r -> {
				synchronized (this) {
					reasoner = r;
				}
			});
		}
	}

}
