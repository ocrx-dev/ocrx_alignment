package jn.ocrx.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.expression.OWLEntityChecker;
import org.semanticweb.owlapi.expression.ShortFormEntityChecker;
import org.semanticweb.owlapi.model.OWLAnnotationAssertionAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.search.EntitySearcher;
import org.semanticweb.owlapi.util.BidirectionalShortFormProviderAdapter;
import org.semanticweb.owlapi.util.ShortFormProvider;
import org.semanticweb.owlapi.util.SimpleShortFormProvider;
import org.semanticweb.owlapi.util.mansyntax.ManchesterOWLSyntaxParser;

public class DLqueryExact {
	
	private Set<RxClinicalDrug> clinicaldrugs;
	public DLqueryExact(String substance, String dosages, String form, String route, String distinction, OWLReasoner reasoner,OWLOntology OCRx, OWLOntologyManager ontomanager,OWLDataFactory factory,OWLOntology OCRxWithAnnotation) {
		String RxCuisub = substance;
		String RxCuidosage = dosages;
		String RxCuiFo = form;
		String RxCuiRoa = route;
		String RxCuiDistinc = distinction;
		// System.out.pinrtln("RxCuiFo "+RxCuiFo);
		String query = "";
		if(!RxCuisub.equals("")) {
			if(RxCuidosage.equals("")) {
				if(RxCuiFo.equals("")) {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000006 onlysome "+RxCuisub
									+")";
						}
						else {
							 query ="1000000000 and (7000000006 onlysome "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000001 onlysome "+RxCuiDistinc+"))";
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000006 onlysome "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 onlysome "+RxCuiRoa+"))";
							
						}
						else {
							 query ="1000000000 and (7000000006 onlysome "+RxCuisub
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 onlysome "+RxCuiRoa+")"
									+" and (7000000001 onlysome "+RxCuiDistinc+")"
									+ ")";
						}
					}
				}
				else {
					
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000006 onlysome "+RxCuisub
									 +") and (7000000008 onlysome   "+RxCuiFo+ ")";
						}
						else {
							query ="1000000000 and (7000000006 onlysome "+RxCuisub
									+") and 7000000008 onlysome ( "+RxCuiFo
									+" and (7000000001 onlysome "+RxCuiDistinc+"))";
						}
						
					}
					else {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000006 onlysome "+RxCuisub
										+") and 7000000008 onlysome (  "+RxCuiFo
										+" and (7000000002 onlysome "+RxCuiRoa+"))";
						}
						else {
							 query ="1000000000 and (7000000006 onlysome "+RxCuisub
										+") and 7000000008 onlysome (  "+RxCuiFo
										+" and (7000000002 onlysome "+RxCuiRoa+")"
										+" and (7000000001 onlysome "+RxCuiDistinc+")"
										+ ")";
						}
					}
				}
			}
			else {
				
				if(RxCuiFo.equals("")) {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							 query ="1000000000 and (7000000006 only ("+RxCuisub
										+" and 7000000004 some "+RxCuidosage
										+ " ) )";
						}
						else {
							query ="1000000000 and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000001 onlysome "+RxCuiDistinc+"))";
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							query ="1000000000 and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 onlysome "+RxCuiRoa+"))";
						}
						else {
							query ="1000000000 and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 some ( 4000000000 "
									+" and (7000000002 onlysome "+RxCuiRoa+")"
									+" and (7000000001 onlysome "+RxCuiDistinc+")"
									+ ")";
							
						}
					}
				}
				else {
					if(RxCuiRoa.equals("")) {
						if(RxCuiDistinc.equals("")) {
							query ="1000000000 and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									 +") and (7000000008 onlysome   "+RxCuiFo+ ")";
						}
						else {
							query ="1000000000 and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 onlysome (  "+RxCuiFo
									+" and (7000000001 onlysome "+RxCuiDistinc+"))";
							
						}
					}
					else {
						if(RxCuiDistinc.equals("")) {
							query ="1000000000 and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 onlysome (  "+RxCuiFo
									+" and (7000000002 onlysome "+RxCuiRoa+"))";
						}
						else {
							query ="1000000000 and (7000000006 only ("+RxCuisub
									+" and 7000000004 some "+RxCuidosage
									+ " ) "
									+") and 7000000008 onlysome (   "+RxCuiFo
									+" and (7000000002 onlysome "+RxCuiRoa+")"
									+" and (7000000001 onlysome "+RxCuiDistinc+")"
									+ ")";
						}
					}
				}
			}
			
		}
		
		
		// System.out.pinrtln(query);
		
		ShortFormProvider prefixe = new SimpleShortFormProvider();
		OWLEntityChecker entityChecker = new ShortFormEntityChecker( new BidirectionalShortFormProviderAdapter(ontomanager,OCRx.getImportsClosure(), prefixe));// System.out.pinrtln(query);
		OWLClassExpression qeryTest =DLqeriSyntax(query, factory, entityChecker, OCRx);
		
		
		
		Set<OWLClass> resu2 =reasoner.getSubClasses(qeryTest,false).getFlattened();
		Set<OWLClass> resu =reasoner.getEquivalentClasses(qeryTest).getEntities();
		
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> equivalentClinicaldrugs = new HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> SubclassClinicaldrugs = new  HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		
		for(OWLClass eq : resu) {
			if(!equivalentClinicaldrugs.containsKey(eq)) {
				equivalentClinicaldrugs.put(eq, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(eq, OCRxWithAnnotation)) {
				equivalentClinicaldrugs.get(eq).add(ax);
			}
		}
		for(OWLClass sub : resu2) {
			if(!SubclassClinicaldrugs.containsKey(sub)) {
				SubclassClinicaldrugs.put(sub, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(sub, OCRxWithAnnotation)) {
				SubclassClinicaldrugs.get(sub).add(ax);
			}
		}
		
		Set<RxDefinitionaFeatures> def = new HashSet<RxDefinitionaFeatures>();
		Set<RxClinicalDrug> CanadianClinicalDrug = new HashSet<RxClinicalDrug>();
		
		for(OWLClass cal : SubclassClinicaldrugs.keySet()) {
			String ccd = cal.getIRI().getShortForm();
				if(!ccd.equals("Nothing")) {
					Set<OWLAnnotationAssertionAxiom> annotation =SubclassClinicaldrugs.get(cal);
					RxClinicalDrug cc = new RxClinicalDrug(annotation, ccd, "SUB_Class");
					CanadianClinicalDrug.add(cc);
				}
		}
		
		for(OWLClass cal : equivalentClinicaldrugs.keySet()) {
			String ccd = cal.getIRI().getShortForm();
			if(!ccd.equals("Nothing")) {
					Set<OWLAnnotationAssertionAxiom> annotation =equivalentClinicaldrugs.get(cal);
					RxClinicalDrug cc = new RxClinicalDrug(annotation, ccd, "Equivalent");
					CanadianClinicalDrug.add(cc);
			}
		}
	
		this.setClinicaldrugs(CanadianClinicalDrug);
		
		
	}
	private OWLClassExpression DLqeriSyntax(String QueryInManchesterSyntax, OWLDataFactory ontologyFactory,OWLEntityChecker entityChecker, OWLOntology ontology) {
		//ManchesterOWLSyntaxParserImpl parser = new ManchesterOWLSyntaxParserImpl(new ontologycon, ontologyFactory)
		//parser.getPrefixManager().setDefaultPrefix("http://www.ocrx.ca/OCRx/");
		//ManchesterOWLSyntaxEditorParser parser = new ManchesterOWLSyntaxEditorParser(ontologyFactory, QueryInManchesterSyntax);
		ManchesterOWLSyntaxParser parser = OWLManager.createManchesterParser();
		parser.setDefaultOntology(ontology);
		parser.setOWLEntityChecker(entityChecker);
		parser.setStringToParse(QueryInManchesterSyntax);
		OWLClassExpression classeExpression=parser.parseClassExpression();
		return classeExpression;
	}
	public Set<RxClinicalDrug> getClinicaldrugs() {
		return clinicaldrugs;
	}
	public void setClinicaldrugs(Set<RxClinicalDrug> clinicaldrugs) {
		this.clinicaldrugs = clinicaldrugs;
	}

}
