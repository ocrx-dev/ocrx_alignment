package jn.ocrx;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jn.ocrx.singleton.infoDataBase;

@Controller
public class OCRXController {




	@Value("${version.number}")
	private String versionNumber;

	//private final Logger log = LoggerFactory.getLogger(this.getClass());

	@RequestMapping("/")
	public String wellcome(Model m) {
		m.addAttribute("version", versionNumber);
		return "home";
	}
	@RequestMapping("/papyRx")
	public String browser(Model m) {

		m.addAttribute("version", versionNumber);
		// To check if retrieving take many time (I do not think so)
		m.addAttribute("forms",infoDataBase.getLabels("forms"));
		m.addAttribute("substances",infoDataBase.getLabels("substances"));
		m.addAttribute("routes",infoDataBase.getLabels("routes of administration"));
		return "browser2";
	}

	





}
