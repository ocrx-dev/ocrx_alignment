package jn.ocrx.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.semanticweb.owlapi.util.BidirectionalShortFormProviderAdapter;
import org.semanticweb.owlapi.util.DefaultPrefixManager;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.expression.OWLEntityChecker;
import org.semanticweb.owlapi.expression.ShortFormEntityChecker;
import org.semanticweb.owlapi.manchestersyntax.parser.ManchesterOWLSyntaxParserImpl;
import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLAnnotationAssertionAxiom;
import org.semanticweb.owlapi.model.OWLAnnotationValue;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDatatype;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyLoaderConfiguration;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.search.EntitySearcher;
import org.semanticweb.owlapi.util.ShortFormProvider;
import org.semanticweb.owlapi.util.SimpleShortFormProvider;
import org.semanticweb.owlapi.util.mansyntax.ManchesterOWLSyntaxParser;

public class DBmanager {
	public Set<RxDefinitionaFeatures> definitional;
	public Set<RxClinicalDrug> clinicaldrugs;
	public DBmanager(String RxCuiSubstance, String RxCuiForm,String RxCuiROAD, OWLReasoner reasoner,OWLOntology OCRx, OWLOntologyManager ontomanager,OWLDataFactory factory,OWLOntology OCRxWithAnnotation) {
		
		String RxCuisub = RxCuiSubstance;
		String RxCuiFo = RxCuiForm;
		String RxCuiRoa = RxCuiROAD;
		PrefixManager pm= new DefaultPrefixManager("http://www.ocrx.ca/OCRx/");
		OWLClass SubsClass = factory.getOWLClass(RxCuisub, pm);
		Set<OWLAnnotationAssertionAxiom> AnnotationSubstance = new HashSet<OWLAnnotationAssertionAxiom>();
		Set<OWLAnnotationAssertionAxiom> AnnotationRouteOfAdministration = new HashSet<OWLAnnotationAssertionAxiom>();
		Set<OWLAnnotationAssertionAxiom> AnnotationFormes = new HashSet<OWLAnnotationAssertionAxiom>();
		
		for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(SubsClass, OCRxWithAnnotation)) {
			AnnotationSubstance.add(ax);
		}
		
		if(!RxCuiRoa.equals("")) {
			OWLClass RoaClass = factory.getOWLClass(RxCuiRoa, pm);
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(RoaClass, OCRxWithAnnotation)) {
				AnnotationRouteOfAdministration.add(ax);
			}
		}
		
		if(!RxCuiFo.equals("")) {			
			OWLClass FoClass = factory.getOWLClass(RxCuiFo, pm);
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(FoClass, OCRxWithAnnotation)) {
				AnnotationFormes.add(ax);
			}
		}
		
		
		String query = "";
		if(RxCuiRoa.equals("")) {
			if(RxCuiFo.equals("")) {
				if(!RxCuisub.equals("")) {
					query=QuerySubsTance(RxCuisub);
				}
			}
			else {
				query=QuerySubsTanceForm(RxCuisub, RxCuiFo);
			}
		}
		else {
			if(RxCuiFo.equals("")) {
				query=QuerySubsTanceRoad(RxCuisub, RxCuiRoa);
			}
			else {
				query=Query(RxCuisub, RxCuiFo, RxCuiRoa);
			}
		}
		
		
		ShortFormProvider prefixe = new SimpleShortFormProvider();
		OWLEntityChecker entityChecker = new ShortFormEntityChecker( new BidirectionalShortFormProviderAdapter(ontomanager,OCRx.getImportsClosure(), prefixe));// System.out.pinrtln(query);
		OWLClassExpression qeryTest =DLqeriSyntax(query, factory, entityChecker, OCRx);
		
		
		
		Set<OWLClass> resu2 =reasoner.getSubClasses(qeryTest,false).getFlattened();
		Set<OWLClass> resu =reasoner.getEquivalentClasses(qeryTest).getEntities();
		
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> equivalentClinicaldrugs = new HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		Map<OWLClass,Set<OWLAnnotationAssertionAxiom>> SubclassClinicaldrugs = new  HashMap<OWLClass, Set<OWLAnnotationAssertionAxiom>>();
		
		for(OWLClass eq : resu) {
			if(!equivalentClinicaldrugs.containsKey(eq)) {
				equivalentClinicaldrugs.put(eq, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(eq, OCRxWithAnnotation)) {
				equivalentClinicaldrugs.get(eq).add(ax);
			}
		}
		for(OWLClass sub : resu2) {
			if(!SubclassClinicaldrugs.containsKey(sub)) {
				SubclassClinicaldrugs.put(sub, new HashSet<OWLAnnotationAssertionAxiom>());
			}
			for(OWLAnnotationAssertionAxiom ax :EntitySearcher.getAnnotationAssertionAxioms(sub, OCRxWithAnnotation)) {
				SubclassClinicaldrugs.get(sub).add(ax);
			}
		}
		
		Set<RxDefinitionaFeatures> def = new HashSet<RxDefinitionaFeatures>();
		Set<RxClinicalDrug> CanadianClinicalDrug = new HashSet<RxClinicalDrug>();
		
		RxDefinitionaFeatures subs = new RxDefinitionaFeatures(AnnotationSubstance, RxCuisub, "Substance");
		RxDefinitionaFeatures form = new RxDefinitionaFeatures(AnnotationFormes, RxCuiFo, "Form");
		RxDefinitionaFeatures RoA = new RxDefinitionaFeatures(AnnotationRouteOfAdministration, RxCuiRoa, " Route of Administration");
		def.add(RoA);
		def.add(subs);
		def.add(form);
		
		for(OWLClass cal : SubclassClinicaldrugs.keySet()) {
			String ccd = cal.getIRI().getShortForm();
					Set<OWLAnnotationAssertionAxiom> annotation =SubclassClinicaldrugs.get(cal);
					RxClinicalDrug cc = new RxClinicalDrug(annotation, ccd, "SUB_Class");
					CanadianClinicalDrug.add(cc);
		}
		
		for(OWLClass cal : equivalentClinicaldrugs.keySet()) {
			String ccd = cal.getIRI().getShortForm();
					Set<OWLAnnotationAssertionAxiom> annotation =equivalentClinicaldrugs.get(cal);
					RxClinicalDrug cc = new RxClinicalDrug(annotation, ccd, "Equivalent");
					CanadianClinicalDrug.add(cc);
		}
		this.definitional=def;
		this.clinicaldrugs=CanadianClinicalDrug;
		Set<RxClinicalDrug> clini = new HashSet<RxClinicalDrug>();
		
	}
	
	

	private OWLClassExpression DLqeriSyntax(String QueryInManchesterSyntax, OWLDataFactory ontologyFactory,OWLEntityChecker entityChecker, OWLOntology ontology) {
		//ManchesterOWLSyntaxParserImpl parser = new ManchesterOWLSyntaxParserImpl(new ontologycon, ontologyFactory)
		//parser.getPrefixManager().setDefaultPrefix("http://www.ocrx.ca/OCRx/");
		//ManchesterOWLSyntaxEditorParser parser = new ManchesterOWLSyntaxEditorParser(ontologyFactory, QueryInManchesterSyntax);
		ManchesterOWLSyntaxParser parser = OWLManager.createManchesterParser();
		parser.setDefaultOntology(ontology);
		parser.setOWLEntityChecker(entityChecker);
		parser.setStringToParse(QueryInManchesterSyntax);
		OWLClassExpression classeExpression=parser.parseClassExpression();
		return classeExpression;
	}
	private String QuerySubsTanceForm(String RxCuiSubstance, String RxCuiForm) {
		String query ="1000000000 and 7000000007 some "+RxCuiSubstance
				+" and (7000000008 some "+RxCuiForm+")";
		return query;
	}
	private String QuerySubsTanceRoad(String RxCuiSubstance, String RxCuiROAD) {
		String query ="1000000000 and (7000000007 some "+RxCuiSubstance
				+") and (7000000008 some ( 1000000000"
				+" and 7000000002 some "+RxCuiROAD+"))";
		return query;
	}
	private String QuerySubsTance(String RxCuiSubstance) {
		String query ="1000000000 and 7000000007 some "+RxCuiSubstance;
		return query;
	}
	private String Query(String RxCuiSubstance, String RxCuiForm,String RxCuiROAD) {
		
		String query ="1000000000 and (7000000007 some "+RxCuiSubstance
				+") and 7000000008 some ( "+RxCuiForm
				+" and (7000000002 some "+RxCuiROAD+"))";
		return query;
		
	}
	
	

}
