package jn.ocrx.core;

import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.model.OWLAnnotationAssertionAxiom;
import org.semanticweb.owlapi.model.OWLAnnotationValue;
import org.semanticweb.owlapi.model.OWLDatatype;
import org.semanticweb.owlapi.model.OWLLiteral;

public class RxConceptGeneral {

	private RxConcept Concept;
	private Set<RxMapping> mappings;
	private String RxCui;
	private String TTY;
	public RxConceptGeneral(Set<OWLAnnotationAssertionAxiom> Annotation, String RxCUI,String TTY) {
		// TODO Auto-generated constructor stub
		Set<RxMapping> mappingsT = new HashSet<RxMapping>();
		String Comment ="";
		Set<String> labels = new HashSet<String>();
		for(OWLAnnotationAssertionAxiom ax : Annotation) {
			String namespace = ax.getProperty().getIRI().getNamespace();
			String porperty = ax.getProperty().getIRI().getShortForm();
			OWLAnnotationValue val =ax.getValue();
			OWLLiteral li =val.asLiteral().get();
			String lang=li.getLang();
			String valeur=li.getLiteral();
			OWLDatatype dala=li.getDatatype();
			String dal = dala.getIRI().getShortForm();
			dal=dal.replace("1", "");
			dal=dal.replace("2", "");
			
			if(namespace.equals("http://www.ocrx.ca/OCRx/XRef:")) {
				String XRef =valeur;
				String SOURCES =porperty;
				String SOURCETYPE =dal;
				RxMapping map = new RxMapping(RxCUI, XRef, SOURCES, SOURCETYPE);
				mappingsT.add(map);
			}
			
			

			if(namespace.equals("http://www.w3.org/2000/01/rdf-schema#")) {
					if(porperty.equals("comment")) {
						if(lang.equals("en")) {
							Comment=valeur;
						}
					}
					if(porperty.equals("label")) {
						if(lang.equals("en")) {
							labels.add(valeur);
						}
					}
			}
			
		}
		String type="Canadian Clinical drug";
		RxConcept concep= new RxConcept(RxCUI, labels, Comment, type);
		this.setRxCui(RxCUI);
		this.setConcept(concep);
		this.mappings=mappingsT;
		this.TTY=TTY;
		
		
	}
	public RxConcept getConcept() {
		return Concept;
	}
	public void setConcept(RxConcept concept) {
		Concept = concept;
	}
	public Set<RxMapping> getMappings() {
		return mappings;
	}
	public void setMappings(Set<RxMapping> mappings) {
		this.mappings = mappings;
	}
	public String getRxCui() {
		return RxCui;
	}
	public void setRxCui(String rxCui) {
		RxCui = rxCui;
	}
	
	
	private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RxConceptGeneral)) return false;
        RxConceptGeneral other = (RxConceptGeneral) obj;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.Concept==null && other.getConcept()==null) || 
             (this.Concept!=null &&
              this.Concept.equals(other.getConcept())))  &&
            ((this.TTY==null && other.getTTY()==null) || 
              (this.TTY!=null &&
               this.TTY.equals(other.getTTY())))  &&
            ((this.RxCui==null && other.getRxCui()==null) || 
             (this.RxCui!=null &&
              this.RxCui.equals(other.getRxCui())))  &&
            ((this.mappings==null && other.getMappings()==null) || 
             (this.mappings!=null &&
              this.mappings.equals(other.getMappings())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getConcept() != null) {
            _hashCode += getConcept().hashCode();
        }
       
        if (getRxCui() != null) {
            _hashCode += getRxCui().hashCode();
        }
        if (getMappings() != null) {
            _hashCode += getMappings().hashCode();
        }
        if (getTTY() != null) {
            _hashCode += getTTY().hashCode();
        }
        
        
        __hashCodeCalc = false;
        return _hashCode;
    }
	public String getTTY() {
		return TTY;
	}
	public void setTTY(String tTY) {
		TTY = tTY;
	}
	



}
