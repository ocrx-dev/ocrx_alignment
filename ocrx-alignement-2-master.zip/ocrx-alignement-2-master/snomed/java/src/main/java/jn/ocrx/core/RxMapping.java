package jn.ocrx.core;

import java.util.Set;

/**
 * a mettre dans le beans 
 * @author jnikiema
 *
 */
public class RxMapping{
	private java.lang.String RXCUI;
	private java.lang.String XREF;
	private java.lang.String SOURCE;
	private java.lang.String SOURCETYPE ;
	 public RxMapping(
	            java.lang.String RXCUI,
	            java.lang.String XREF,
	            java.lang.String SOURCE,
	            java.lang.String SOURCETYPE) {
	            
	            this.setRXCUI(RXCUI);
	            this.setXREF(XREF);
	            this.setSOURCE(SOURCE);
	            this.setSOURCETYPE(SOURCETYPE);
	     }
	public java.lang.String getRXCUI() {
		return RXCUI;
	}
	public void setRXCUI(java.lang.String rXCUI) {
		RXCUI = rXCUI;
	}
	public java.lang.String getXREF() {
		return XREF;
	}
	public void setXREF(java.lang.String xREF) {
		XREF = xREF;
	}
	public java.lang.String getSOURCE() {
		return SOURCE;
	}
	public void setSOURCE(java.lang.String sOURCE) {
		SOURCE = sOURCE;
	}
	public java.lang.String getSOURCETYPE() {
		return SOURCETYPE;
	}
	public void setSOURCETYPE(java.lang.String sOURCETYPE) {
		SOURCETYPE = sOURCETYPE;
	}
	
	private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RxMapping)) return false;
        RxMapping other = (RxMapping) obj;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.XREF==null && other.getXREF()==null) || 
             (this.XREF!=null &&
              this.XREF.equals(other.getXREF())))  &&
            ((this.RXCUI==null && other.getRXCUI()==null) || 
             (this.RXCUI!=null &&
              this.RXCUI.equals(other.getRXCUI()))) &&
            ((this.SOURCETYPE==null && other.getSOURCETYPE()==null) || 
             (this.SOURCETYPE!=null &&
              this.SOURCETYPE.equals(other.getSOURCETYPE()))) &&
            ((this.SOURCE==null && other.getSOURCE()==null) || 
             (this.SOURCE!=null &&
              this.SOURCE.equals(other.getSOURCE())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getXREF() != null) {
            _hashCode += getXREF().hashCode();
        }
       
        if (getRXCUI() != null) {
            _hashCode += getRXCUI().hashCode();
        }
        if (getSOURCE() != null) {
            _hashCode += getSOURCE().hashCode();
        }
        if (getSOURCETYPE() != null) {
            _hashCode += getSOURCETYPE().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }
	

    

}
