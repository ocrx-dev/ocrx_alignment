package jn.ocrx;

import java.io.File;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.mindswap.pellet.jena.PelletReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.util.InferredAxiomGenerator;
import org.semanticweb.owlapi.util.InferredOntologyGenerator;
import org.semanticweb.owlapi.util.InferredSubClassAxiomGenerator;
import org.semanticweb.owlapi.util.InferredEquivalentClassAxiomGenerator;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

import java.util.ArrayList;
import java.util.List;
import java.io.File;

import org.semanticweb.elk.owlapi.ElkReasonerFactory;

public class SnomedCT_queries {
    private static OWLOntologyManager ontomanager = OWLManager.createOWLOntologyManager();

    public static void main(String[] args) throws OWLOntologyStorageException,
            OWLOntologyCreationException {
        OWLOntologyManager inputOntologyManager = OWLManager.createOWLOntologyManager();
        OWLOntologyManager outputOntologyManager = OWLManager.createOWLOntologyManager();

        // Load your ontology.
        OWLOntology ont = inputOntologyManager.loadOntologyFromOntologyDocument(new File("src/main/resources/static/ontologies/snomed.owl"));

        // Create an ELK reasoner.
        OWLReasonerFactory reasonerFactory = new ElkReasonerFactory();
        OWLReasoner reasoner = reasonerFactory.createReasoner(ont);

        // Classify the ontology.
        reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);

        // To generate an inferred ontology we use implementations of
        // inferred axiom generators
        List<InferredAxiomGenerator<? extends OWLAxiom>> gens = new ArrayList<InferredAxiomGenerator<? extends OWLAxiom>>();
        gens.add(new InferredSubClassAxiomGenerator());
        gens.add(new InferredEquivalentClassAxiomGenerator());

        // Put the inferred axioms into a fresh empty ontology.
        OWLOntology infOnt = outputOntologyManager.createOntology();
        InferredOntologyGenerator iog = new InferredOntologyGenerator(reasoner,
                gens);
        iog.fillOntology(outputOntologyManager.getOWLDataFactory(), infOnt);

        // Save the inferred ontology.
        // outputOntologyManager.saveOntology(infOnt,
                // IRI.create((new File("src/main/resources/static/ontologies/ocrx-computed.owl").toURI())));

        // Terminate the worker threads used by the reasoner.
        reasoner.dispose();
    }
}
