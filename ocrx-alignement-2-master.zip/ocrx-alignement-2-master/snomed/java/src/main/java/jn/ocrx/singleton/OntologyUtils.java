package jn.ocrx.singleton;


import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.OWLReasoner;


public class OntologyUtils {
	private  OWLOntology OCRx;
	private  OWLOntology OCRx2;
	private  OWLReasoner reasoner;
	
	public OntologyUtils() {
		this.setOCRx(null);
		this.setOCRx2(null);
		this.setReasoner(null);
	}

	public OWLOntology getOCRx() {
		return this.OCRx;
	}

	public void setOCRx(OWLOntology oCRx) {
		this.OCRx = oCRx;
	}

	public OWLOntology getOCRx2() {
		return this.OCRx2;
	}

	public void setOCRx2(OWLOntology oCRx2) {
		this.OCRx2 = oCRx2;
	}

	public OWLReasoner getReasoner() {
		return this.reasoner;
	}

	public void setReasoner(OWLReasoner reasoner) {
		this.reasoner = reasoner;
	}


}
