package jn.ocrx.core;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;


public class TokenManager {
    private Connection con;
    private int logRounds = 10;

    public TokenManager() {
        createConnection();
    }

    public void createConnection() {
        Connection c = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:tokens.db");
            DatabaseMetaData meta = c.getMetaData();
            ResultSet set = meta.getTables(null, null, "TOKENS", new String[] { "TABLE" });
            if (!set.next()) {
                String sql = "CREATE TABLE TOKENS (ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, EMAIL TEXT NOT NULL, TOKEN TEXT NOT NULL)";
                c.createStatement().executeUpdate(sql);
            }
            con = c;
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        // System.out.pinrtln("Opened tokens database successfully");
    }

    public Connection getConnection() {
        return con;
    }

    String generateRandomString(int length) throws NoSuchAlgorithmException {
        String chrs = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        SecureRandom secureRandom = SecureRandom.getInstanceStrong();
        // 9 is the length of the string you want
        String customTag = secureRandom.ints(length, 0, chrs.length()).mapToObj(i -> chrs.charAt(i))
                .collect(StringBuilder::new, StringBuilder::append, StringBuilder::append).toString();
        return customTag;
    }

    public void insertToken(String email, String rawToken) throws SQLException {
        Connection con = getConnection();
        String hashedToken = hashToken(rawToken);
        String query = "INSERT INTO TOKENS (EMAIL,TOKEN) VALUES (?1, ?2)";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, email);
        ps.setString(2, hashedToken);
        ps.executeUpdate();
    }

    public String hashToken(String rawToken) {
        byte[] salt = "EfGXPnU6ZS3YOvFTIHBD".getBytes();
        KeySpec spec = new PBEKeySpec(rawToken.toCharArray(), salt, 65536, 128);
        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            byte[] hash;
            hash = factory.generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (InvalidKeySpecException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        }
    }

    public boolean verifyToken(String rawToken) {
        try {
            Connection con = getConnection();
            String hashedToken = hashToken(rawToken);
            String query = "SELECT * FROM TOKENS WHERE TOKEN=?1";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, hashedToken);
            boolean valid = ps.execute(query);
            return valid;
        } catch (Exception e) {
            return false;
        }

    }

    public void deleteToken(String email) throws SQLException {
        Connection con = getConnection();
        String query = "DELETE FROM TOKENS WHERE EMAIL=?1";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, email);
        ps.execute();
    }

    public void refreshToken(String email, String rawToken) throws SQLException {
        deleteToken(email);
        insertToken(email, rawToken);
    }

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        TokenManager tm = new TokenManager();
        String secret = "René Über";
        String cipherText = "U2FsdGVkX1+YO+ApJZr88SpbNcB+vNUwdkuH6C9Cmi6Kgcz28KoEe7m5LJBm9+X6T+9iC9jGh4SEDkDEY0fyYDxiGJxmJojTbisW/AXkGBc=";
        AESHelper.decrypt(cipherText, secret);
        // System.out.pinrtln(tm.generateRandomString(40));
    }
}
